/*
 * Copyright 2007,2008 Nobuhiro Iwamatsu <iwamatsu@nigauri.org>
 * Copyright (C) 2008 Renesas Solutions Corp.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#include <common.h>

int interrupt_init(void)
{
	return 0;
}

void enable_interrupts(void)
{

}

int disable_interrupts(void)
{
	return 0;
}
