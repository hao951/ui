/*
 * Copyright (c) 2011, Google Inc. All rights reserved.
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _TEGRA_MMC_H_
#define _TEGRA_MMC_H_

void tegra_mmc_init(void);

#endif /* _TEGRA_MMC_H_ */
