/*
 * Copyright 2015 Xilinx, Inc.
 *
 * SPDX-License-Identifier:      GPL-2.0+
 */

#ifndef __ARCH_ZYNQMP_GPIO_H
#define __ARCH_ZYNQMP_GPIO_H

/* Empty file - sdhci requires this. */

#endif
