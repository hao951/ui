/* SPARC atomic operations
 *
 * (C) Copyright 2008
 * Daniel Hellstrom, Gaisler Research, daniel@gaisler.com.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _ASM_SPARC_ATOMIC_H_
#define _ASM_SPARC_ATOMIC_H_

#endif	/* _ASM_SPARC_ATOMIC_H_ */
