#ifndef _ASM_X86_LINKAGE_H
#define _ASM_X86_LINKAGE_H

#define asmlinkage CPP_ASMLINKAGE __attribute__((regparm(0)))

#endif /* _ASM_X86_LINKAGE_H */
